import { Controller } from '@hotwired/stimulus';
import '@hotwired/turbo';

class turbo_controller extends Controller {
}

export { turbo_controller as default };
